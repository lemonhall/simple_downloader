(function() {
    'use strict';

    document.addEventListener("keyup", function (event) {
        // 79 是 o 键的键码
        if (event.keyCode === 79 || event.keyCode === 111) {
            //let videoInfoDetailElement = document.querySelector('.video-info-detail');
            //let videoId = videoInfoDetailElement.getAttribute('data-e2e-aweme-id');
            let targetDivDom = document.querySelector('[data-e2e="feed-active-video"]');
            let videoId = targetDivDom.getAttribute("data-e2e-vid");
            console.log(videoId);
            alert("你好！"+videoId);
            let p = {};
            p.videoId = videoId;
    
            chrome.runtime.sendMessage(p, function (response) {
              if (chrome.runtime.lastError) {
                alert("chrome.runtime.lastError")
                console.log(chrome.runtime.lastError.message);
              } else {
                if (response.status === "ok") {
                    console.log(response.videoLink)
                                  let data ={};
                                  data.videoId  = videoId;
                                  data.videoUrl =response.videoLink;
                                  console.log("抖音下载小助手，下载前的payload构造打印：");
                                  console.log(data);
                                  var xhr = new XMLHttpRequest();

                                  xhr.open("POST", "http://localhost:8000/videos", true);
                                  
                                  xhr.setRequestHeader("Content-Type", "application/json");
                                  
                                  xhr.onreadystatechange = function() {
                                    if (xhr.readyState == 4 && xhr.status == 200) {
                                      var response = xhr.responseText;
                                      console.log(response);
                                    }
                                  };
                                  
                                  var payload = JSON.stringify(data);
                                  
                                  xhr.send(payload);
                } else {
                    alert("failed from background")
                }
              }
            });
        }
    });
})();