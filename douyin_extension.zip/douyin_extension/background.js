//background.js
let urlList = [];
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const link = details.url;
    //if (link.includes("zjcdn") && urlList.at(-1) !== link) {
    //   if (urlList.length > 50) {
    //     urlList.shift();
    //   }
      urlList.push(link);
    //}
  },
  { urls: ["https://*.douyinvod.com/*"] }

);

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    console.log(request);
    const videoLink = urlList.find((link) => link.includes(request.videoId));

    sendResponse({ status: "ok", videoLink:videoLink});
    // Return true to keep the message channel open
    return true;
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (tab.url && tab.url.includes("douyin.com")) {
    chrome.action.setPopup({ tabId: tabId, popup: "popup.html" });
  } else {
    chrome.action.setPopup({ tabId: tabId, popup: "" }); // No popup for other sites
  }
});