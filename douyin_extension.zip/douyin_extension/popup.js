function listMp4Files() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://localhost:8000/list_mp4_files');
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4 && xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        const mp4FilesList = document.getElementById('mp4FilesList');
  
        data.mp4_files.forEach(file => {
          const li = document.createElement('li');
  
          // 创建 HTML5 视频元素
          const video = document.createElement('video');
          video.src = file;
          video.controls = true;
          video.width = 300;  // 设置宽度为 300 像素
          video.height = 200;  // 设置高度为 200 像素

                    // 创建删除按钮
                    const deleteButton = document.createElement('button');
                    deleteButton.innerHTML = '🗑️';
                    deleteButton.addEventListener('click', () => {
                        const liElement = event.target.parentNode;
                        const videoSrc = event.target.parentNode.querySelector('video').src;
                        if (confirm('确定要删除该视频吗？')) {
                            // 执行删除操作的代码
                                    const xhr = new XMLHttpRequest();
                                    xhr.open('POST', 'http://localhost:8000/delete_video'); 
                                    xhr.setRequestHeader('Content-Type', 'application/json');
                                
                                    xhr.onreadystatechange = function () {
                                    if (xhr.readyState === 4 && xhr.status === 200) {
                                        // 删除成功后的处理逻辑
                                        console.log('视频删除成功');
                                        // 删除或隐藏 video 元素
                                        // videoElement.remove(); 
                                        // 或者 
                                        liElement.style.display = 'none'; 
                                    } else if (xhr.readyState === 4 && xhr.status!== 200) {
                                        // 处理错误情况
                                        console.error('删除视频失败，状态码:', xhr.status);
                                    }
                                    };
                                
                                    const params = JSON.stringify({ src: videoSrc }); 
                                
                                    xhr.send(params);
                        }//End of confirm('确定要删除该视频吗？')
                      });
  
          li.appendChild(video);
          li.appendChild(deleteButton);
          mp4FilesList.appendChild(li);
        });
      }
    };
    xhr.send();
}

window.addEventListener('load', () => {
    listMp4Files();
});